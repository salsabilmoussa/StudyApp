#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>

#define TUBE_REQUETE "tube_requete"
#define TUBE_REPONSE "tube_reponse"

int main() {
    int req, res, a, b, result, errQ, errS;
    char op;
    char message[256], messageReq[256];

    unlink(TUBE_REQUETE);
    unlink(TUBE_REPONSE);

    errQ = mkfifo(TUBE_REQUETE, 0666);
    errS = mkfifo(TUBE_REPONSE, 0666);

    if (errQ == -1 || errS == -1) {
        printf("Erreur de création de tubes\n");
        exit(EXIT_FAILURE);
    }

    req = open(TUBE_REQUETE, O_RDONLY);
    res = open(TUBE_REPONSE, O_WRONLY);

    while (1) {
        read(req, messageReq, sizeof(messageReq));

        if (strcmp(messageReq, "bye") == 0) {
            printf("Fin du programme ! \n");
            break;
        } else if (strcmp(messageReq, "question") == 0) {
            read(req, messageReq, sizeof(messageReq));
            sscanf(messageReq, "%d%c%d", &a, &op, &b);

            switch (op) {
            case '+':
                result = a + b;
                break;
            case '-':
                result = a - b;
                break;
            case '*':
                result = a * b;
                break;
            case '/':
                if (b != 0) {
                    result = a / b;
                } else {
                    printf("Erreur de division par 0\n");
                    result = 0;
                }
                break;
            default:
                printf("Operation invalide\n");
                result = -999999;
                break;
            }

            sprintf(messageReq, "Le resultat est : %d\n", result);
            write(res, messageReq, sizeof(messageReq));
        }
    }

    close(req);
    close(res);

    unlink(TUBE_REQUETE);
    unlink(TUBE_REPONSE);

    return 0;
}

