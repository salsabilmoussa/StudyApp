#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>

#define TUBE_REQUETE "tube_requete"
#define TUBE_REPONSE "tube_reponse"

int main() {
    char message[256], messageReq[256];
    int req, res, a, b, result;
    char op;


    req = open(TUBE_REQUETE, O_WRONLY);
    res = open(TUBE_REPONSE, O_RDONLY);

    while (1) {
        printf("\nEcrivez 'question' pour requête ou 'bye' pour quitter : ");
        scanf("%s", message);

        write(req, message, strlen(message) + 1);

        if (strcmp(message, "bye") == 0) {
            break;
        }

        if (strcmp(message, "question") == 0) {
            printf("\nDonnez une requête pour l'envoyer au serveur : ");
            scanf("%d%c%d", &a, &op, &b);
            sprintf(messageReq, "%d%c%d", a, op, b);

            write(req, messageReq, strlen(messageReq) + 1);
            sleep(1);

            read(res, messageReq, sizeof(messageReq));
            printf("\n Cote Client : Réponse du serveur : %s\n", messageReq);
            sleep(1);
        }
    }

    close(req);
    close(res);

    return 0;
}

