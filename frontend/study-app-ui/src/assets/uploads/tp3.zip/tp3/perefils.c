#include<stdlib.h> 
#include<unistd.h> 
#include<stdio.h> 
#include<signal.h> 
#include<sys/wait.h> 
#include<sys/types.h> 
#include<fcntl.h> 

void main(){

pid_t p1,p2,p3;
int d1_2[2],d2_1[2],d1_3[2],d3_1[2];
int r1,r2,r3,r4,a,b,m1,m2,s;
r1=pipe(d1_2);
r2=pipe(d2_1);
r3=pipe(d1_3);
r4=pipe(d3_1);

if(r1==-1||r2==-1||r3==-1||r4==-1){
	printf("Erreur de creation des tubes \n");
	exit(0);
}

p1=fork();
if(p1>0){
	p2=fork();

	if(p2>0){		
		p3=fork();
		if(p3==0){
			read(d1_3[0],&a,sizeof(int));
			read(d1_3[0],&b,sizeof(int));
			printf("Je suis le 3eme fils et j ai recu a=%d et b=%d \n",a,b);
			s=a+b;
			write(d3_1[1],&s,sizeof(int));
		
		}else{
			wait(0);
		}
	}else if(p2==0){		read(d1_2[0],&a,sizeof(int));
		read(d1_2[0],&b,sizeof(int));
		printf("Je suis le 2eme fils et j ai recu a=%d et b=%d \n",a,b);
		m1=a*2;
		m2=b*2;
		write(d2_1[1],&m1,sizeof(int));
		write(d2_1[1],&m2,sizeof(int));}
}else if(p1==0){
	printf("Donnez deux entiers\n");
	scanf("%d %d",&a,&b);
	
	write(d1_2[1],&a,sizeof(int));
	write(d1_2[1],&b,sizeof(int));
	write(d1_3[1],&a,sizeof(int));
	write(d1_3[1],&b,sizeof(int));
	
	sleep(3);
	
	read(d2_1[0],&m1,sizeof(int));
	read(d2_1[0],&m2,sizeof(int));
	printf("Je suis le 1er fils et j ai recu de P2 %d et %d \n",m1,m2);
	read(d3_1[0],&s,sizeof(int));
	printf("je suis le 1er fils et j ai recu de P3 la somme %d \n",s);
	exit(1);
}

close(d1_2[0]);
close(d1_2[1]);
close(d2_1[0]);
close(d2_1[1]);
close(d1_3[0]);
close(d1_3[1]);
close(d3_1[0]);
close(d3_1[1]);


}
