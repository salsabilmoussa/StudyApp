#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

typedef struct {
    char nom[100];
    char numero[15];
} AnnuaireEntree;

int main() {
    int cl_socket;
    struct sockaddr_in sa;
    char nom[100];
    AnnuaireEntree reponse;

    cl_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (cl_socket == -1) {
        perror("Erreur lors de la création du socket\n");
        exit(EXIT_FAILURE);
    }

    sa.sin_family = AF_INET;
    sa.sin_port = htons(7000);
    sa.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(cl_socket, (struct sockaddr *)&sa, sizeof(sa));

    printf("Connecté au serveur\n");

    while (1) {
        printf("Entrez le nom ou exit pour quitter: ");
        scanf("%s", nom);

        send(cl_socket, nom, sizeof(nom), 0);

        if (strcmp(nom, "exit") == 0) {
            break;
        }

        recv(cl_socket, &reponse, sizeof(reponse), 0);
         if (strcmp(reponse.nom, "inconnu") == 0) {
            printf("Usager inconnu. Veuillez réessayer.\n");
        }

        printf("\nRéponse du serveur : Nom : %s, Numéro : %s\n", reponse.nom, reponse.numero);
    }

    close(cl_socket);

    return 0;
}

