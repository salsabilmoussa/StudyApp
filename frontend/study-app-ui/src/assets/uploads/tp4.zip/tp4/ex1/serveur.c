#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

typedef struct {
    char nom[100];
    char numero[15];
} AnnuaireEntree;

AnnuaireEntree annuaire[100] = {
    {"aicha", "34567"},
    {"manar", "25649"},
    {"mariem", "90866"},
};

int main() {
    int ser_socket, cl_socket;
    struct sockaddr_in sa, ca;
    socklen_t len = sizeof(ca);
    char nom[100];
    AnnuaireEntree reponse;

    ser_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (ser_socket == -1) {
        perror("Erreur lors de la création du socket\n");
        exit(EXIT_FAILURE);
    }

    sa.sin_family = AF_INET;
    sa.sin_port = htons(7000);
    sa.sin_addr.s_addr = INADDR_ANY;

    bind(ser_socket, (struct sockaddr *)&sa, sizeof(sa));

    listen(ser_socket, 1);

    while (1) {
        cl_socket = accept(ser_socket, (struct sockaddr *)&ca, &len);

        if (cl_socket == -1) {
            printf("Erreur de connexion\n");
            exit(EXIT_FAILURE);
        }

        while (1) {
            recv(cl_socket, nom, sizeof(nom), 0);
            printf("\nRequête du client : %s\n", nom);

            int index = -1;
            for (int i = 0; i < 100; ++i) {
                if (strcmp(annuaire[i].nom, nom) == 0) {
                    index = i;
                    break;  
                }
            }

            if (index == -1) {
                printf("Nom non trouvé dans l'annuaire\n");
                strcpy(reponse.nom, "inconnu");
                strcpy(reponse.numero, "---");
            } else {
                strcpy(reponse.nom, annuaire[index].nom);
                strcpy(reponse.numero, annuaire[index].numero);
            }

            printf("Le nom est %s et le numéro est %s\n", reponse.nom, reponse.numero);
            send(cl_socket, &reponse, sizeof(reponse), 0);

            
            close(cl_socket);
            break; 
        }
    }

    close(ser_socket);

    return 0;
}

