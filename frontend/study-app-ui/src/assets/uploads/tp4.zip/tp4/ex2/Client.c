#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int n1, n2, num;
    char param[50];
    float resultat;
    int client_socket;
    struct sockaddr_in serveraddr;

    client_socket = socket(AF_INET, SOCK_STREAM, 0);

   
    if (client_socket == -1) {
        perror("Erreur lors de la creation de socket");
        exit(EXIT_FAILURE);
    }

    
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_port = htons(7000);
    serveraddr.sin_addr.s_addr = INADDR_ANY;

    
    if (connect(client_socket, (struct sockaddr*)&serveraddr, sizeof(serveraddr)) == -1) {
        perror("Erreur de connection");
        exit(EXIT_FAILURE);
    }

    while (1) {
    	printf("\n******************** MENU ********************************\n");
        printf(" Choix: \n 1.int max (int, int)\n 2.int add (int, int)\n 3.int mult(int,int)\n 4.float div (int, int)\n 5. EXIT");
	printf("\n****************************************************\n");
        printf("\nEntrez votre choix : ");
        scanf("%d", &num);

        
        send(client_socket, &num, sizeof(num), 0);
        if(num==5){exit(0);}
        printf("\nVous devez saisir deux entiers : \n");
        printf("\nEntrez le 1er entier : ");
        scanf("%d",&n1);
        printf("\nEntrez le 2eme entier : ");
        scanf("%d",&n2);
        sprintf(param, "%d %d",n1,n2);

        
        send(client_socket, param, strlen(param), 0);
        
        recv(client_socket, &resultat, sizeof(resultat), 0);
        if(resultat==-2){printf("operateur non valide\n");}
        else{
        	printf("\n******          Resultat     ***********\n");
        	switch(num){
        		case 1 : printf("\nLe max des deux entier %d , %d est : %.2f\n", n1,n2,resultat);break;
        		case 2 : printf("\nLa somme des deux entier %d , %d est : %.2f\n", n1,n2,resultat);break;
        		case 3 : printf("\nLa multiplication des deux entier %d , %d est : %.2f\n", n1,n2,resultat);break;
        		case 4 : { if(resultat!=-1){
        				printf("\nLa division des deux entier %d , %d est : %.2f\n", n1,n2,resultat);
        			   }else{
        			   	printf("\n Erreur de la division \n");
        			   }break;}
        	}
            
        }
    }

    
    close(client_socket);
    return 0;
}

