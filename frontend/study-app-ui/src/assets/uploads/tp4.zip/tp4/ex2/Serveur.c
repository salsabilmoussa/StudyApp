#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int max(int a, int b) {
    return (a > b) ? a : b;
}

int add(int a, int b) {
    return a + b;
}

int mult(int a, int b) {
    return a * b;
}

float divi(int a, int b) {
    if (b != 0) {
        return (float)a / b;
    } else {
        return -1;
    }
}

int main() {
    int n1, n2, num;
    char op[5];
    float resultat;
    int server_socket, client_socket;
    char param[50];
    int amt;
    struct sockaddr_in serveraddr;

    
    server_socket = socket(AF_INET, SOCK_STREAM, 0);

    
    if (server_socket == -1) {
        perror("Erreur lors de la creation de socket");
        exit(EXIT_FAILURE);
    }

    
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_port = htons(7000);
    serveraddr.sin_addr.s_addr = INADDR_ANY;

    
    if (bind(server_socket, (struct sockaddr*)&serveraddr, sizeof(serveraddr)) == -1) {
        perror("Erreur");
        exit(EXIT_FAILURE);
    }

   
    listen(server_socket, 5);

    while (1) {
        
        client_socket = accept(server_socket, (struct sockaddr*)&serveraddr, (socklen_t*)&serveraddr);
        if (client_socket == -1) {
            perror("Erreur de connexion");
            exit(EXIT_FAILURE);
        }

        while(1){
          
            amt = recv(client_socket, &num, sizeof(num), 0); 
            if (amt <= 0) { 
                if (amt < 0) {
                    perror("erreur de reception");
                }
                
                close(client_socket);
                break; 
            }

            printf("le numero de requete est : %d\n", num);

            amt = recv(client_socket, param, sizeof(param), 0);
            param[amt] = '\0';
            printf("la requete recu est : %s\n", param);

            sscanf(param, "%d %d", &n1, &n2);

            switch(num){
                case 1 : resultat=max(n1, n2);break;
                case 2 : resultat=add(n1, n2);break;
                case 3 : resultat=mult(n1, n2);break;
                case 4 : resultat=divi(n1, n2);break;
                default : printf("operation invalide \n");break;
            }
            
            send(client_socket, &resultat, sizeof(resultat), 0);
            printf("resultat envoyé au client\n");
        }
        
        close(client_socket);
    }
    
    close(server_socket);
    return 0;
}

